clear variables;
close all;

%% Liste des variables constantes

eta=1.81*10^-2;
masse=0.2;
rayon=0.05;
l=0.5;
g=9.8;

Theta0=0;
Thetaprime0=0.2;


tmin=0;
tmax=200;


gamma= 6*pi*rayon*eta /masse;
w=sqrt(l/g);

%% Theta"(t) + gamma*Theta'(t) + w² sin(Theta(t)) = 0

% fonction f1 definie par Theta'=z(t)
f1=@(t,Theta,Thetaprime)(Thetaprime);
% fonction 2 definie par z'=-gamma*theta'(t) + w²sin(Theta)
f2=@(t,Theta,Thetaprime)(-gamma*Thetaprime - w^2*sin(Theta));


%% Euler

h=0.02;
[Thetaprime,Theta,t]=Euler_2D(Thetaprime0,Theta0,tmin,tmax,h,f1,f2);

figure(1);hold on;
plot(t,Theta,'c');
plot(t,Thetaprime,'m');
lg=legend('Theta','Thetaprime');


Theta_x=l*sin(Theta);
Theta_y=-l*cos(Theta);

c=length(Theta_x);

figure(2)


Pos1=zeros(1,2);
Pos2=zeros(1,2);

v=VideoWriter('pendule.avi');
open(v);

for a=c(end):-1:c(1)
 Pos2(1)=l*sin(Theta(a));
 Pos2(2)=l*cos(Theta(a));
 plot(Pos1,Pos2,'linewidth',2);
 
 drawnow;
 thisframe=getframe(gcf);
 writeVideo(v,thisframe);
end
close(v);







