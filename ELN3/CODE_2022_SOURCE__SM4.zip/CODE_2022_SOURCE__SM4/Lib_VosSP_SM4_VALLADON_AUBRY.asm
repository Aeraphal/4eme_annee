 ;-----------------------------------------------------------------------------
;
;  FILE NAME   :  LIB_VOSSP_SM4.ASM 
;  TARGET MCU  :  C8051F020 
;  

;-----------------------------------------------------------------------------
$include (c8051f020.inc)               ; Include register definition file. 
;-----------------------------------------------------------------------------
;******************************************************************************
;Declaration des variables et fonctions publiques
;******************************************************************************
PUBLIC   _Read_code
PUBLIC   _Read_Park_IN
PUBLIC   _Read_Park_OUT
PUBLIC   _Decod_BIN_to_BCD
PUBLIC   _Display
PUBLIC   _Test_Code
PUBLIC   _Stockage_Code

;-----------------------------------------------------------------------------
; EQUATES
;-----------------------------------------------------------------------------
GREEN_LED      	equ   	P1.6             ; Port I/O pin connected to Green LED.

;-----------------------------------------------------------------------------
; CODE SEGMENT
;-----------------------------------------------------------------------------
ProgSP_base      segment  CODE

               rseg     ProgSP_base      ; Switch to this code segment.
               using    0              ; Specify register bank for the following
                                       ; program code.
;------------------------------------------------------------------------------
;******************************************************************************                
; _Read_code
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse du p�riph�rique d�entr�e
; Valeur retourn�e: R7 : contient la valeur du code lu (sur les 6 bits de poids faible). 
; Registres modifi�s: aucun
;******************************************************************************    

_Read_code:
              PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  MOV DPL, R7
			  MOV DPH, R6
			  MOVX A, @DPTR
			  CLR ACC.7
			  CLR ACC.0
			  RR A
			  MOV R7, A
			  POP DPH
			  POP DPL
			  POP ACC
              RET
;******************************************************************************    			  
			  
;******************************************************************************                
; _Read_Park_IN
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse du p�riph�rique d�entr�e
; Valeur retourn�e: Bit Carry  0: pas de d�tection / 1: v�hicule d�tect� 
; Registres modifi�s: aucun
;******************************************************************************    

_Read_Park_IN:
              PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  MOV DPL, R7
			  MOV DPH, R6
			  MOVX A, @DPTR
			  MOV C, ACC.0
			  POP DPH
			  POP DPL
		      POP ACC
		      RET
;******************************************************************************    						  
			  
;******************************************************************************                
; _Read_Park_OUT
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse du p�riph�rique d�entr�e
; Valeur retourn�e: Bit Carry  0: pas de d�tection / 1: v�hicule d�tect� 
; Registres modifi�s: aucun
;******************************************************************************    

_Read_Park_OUT:
              PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  
			  MOV DPL, R7
			  MOV DPH, R6			  
			  MOVX A, @DPTR
			  MOV C, ACC.7
			  POP DPH
			  POP DPL
		      POP ACC
              RET
;****************************************************************************** 

;******************************************************************************                
; _Decod_BIN_to_BCD 
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse CODE de la table de conversion
;                                            "Display_7S"
; Param�tres d'entr�e:  R5  � Valeur 4 bits � convertir (4bits de poids faible)
; Valeur retourn�e: R7 - Code 7 segments (Bit 0-Segment a __ Bit6-Segment g)
; Registres modifi�s: aucun
;******************************************************************************    

_Decod_BIN_to_BCD:
              PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  
			  MOV DPL, R7
			  MOV DPH, R6
			  MOV A, R5
			  ANL A, #00001111b
			  MOVC A, @A+DPTR
			  CLR ACC.7
			  MOV R7, A
			  
			  POP DPH
			  POP DPL
		      POP ACC
              RET

;****************************************************************************** 

;******************************************************************************                
; _Display  
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse du p�riph�rique de sortie
; Param�tre d�entr�e :  R5 � Code 7 segments (les 7 bits de poids faible)
; Param�tre d�entr�e :  R3 � Code LED : si 0, LED �teinte, si non nul : LED allum�e
; Valeur retourn�e: R7 : contient une recopie de la valeur envoy�e au p�riph�rique de sortie. 
; Registres modifi�s: aucun
;******************************************************************************    

_Display:
              PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  
			  MOV DPL, R7
			  MOV DPH, R6
			  MOV A, R3
			  JZ eteint_led
			  MOV A, R5
			  SETB ACC.7
			  MOVX @DPTR, A
			  MOV R7, A
			  
			  POP DPH
			  POP DPL
		      POP ACC
              RET
			  
eteint_led:
			  MOV A, R5
			  CLR ACC.7
			  MOVX @DPTR, A
			  MOV R7, A
			  
			  POP DPH
			  POP DPL
		      POP ACC
			  RET 
;****************************************************************************** 

;******************************************************************************                
; _Test_Code  
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse de Tab_code
; Param�tre d�entr�e :  R5  � Code � v�rifier (sur 6 bits)
; Valeur retourn�e: R7 : non nul, il retourne la position du code trouv� dans la table,
;                        nul, il indique que le code n�a pas �t� trouv� dans la table.
; Registres modifi�s: aucun
;******************************************************************************    

_Test_Code:
		      PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  PUSH AR4
			  
			  MOV DPL, R7
			  MOV DPH, R6
			  CLR A
			  
			  MOVC A, @A + DPTR
			  MOV R4, A
			  
			  boucle:
			  MOV A, R4
			  MOVC A, @A + DPTR
			  ANL A, #00111111b
			  CJNE A, AR5, saut
			  SJMP code_valide
			  saut:
			  DJNZ R4, boucle
			  MOV R7, #00h
			  
			  POP AR4
			  POP DPH
			  POP DPL
		      POP ACC
              RET

code_valide:
			  MOV R7, AR4
			  POP AR4
			  POP DPH
			  POP DPL
		      POP ACC
			  RET
			  
;****************************************************************************** 

;******************************************************************************                
; _Stockage_Code 
;
; Description: 
;
; Param�tres d'entr�e:  R6 (MSB)- R7 (LSB) � Adresse de Tab_histo
; Param�tre d�entr�e :  R5 � Code � enregistrer
; Valeur retourn�e: R7 : R7 : non nul, il retourne le nombre d�enregistrements,
;                             nul, il indique que la table est pleine (100 enregistrements). 
; Registres modifi�s: aucun
;******************************************************************************    

_Stockage_Code:
		      PUSH ACC
			  PUSH DPL
			  PUSH DPH
			  
			  MOV DPL, R7
			  MOV DPH, R6
			  MOVX A,@DPTR
			  CJNE A,#64h,table_non_pleine
			  SJMP table_pleine
			  table_non_pleine:
			  INC A
			  MOVX @DPTR, A
			  MOV R7,A
			  CLR C
			  ADDC A, DPL
			  MOV DPL, A
			  CLR A
			  ADDC A, DPH
			  MOV DPH,A
			  MOV A, R5
			  MOVX @DPTR, A
			  
			  POP DPH
			  POP DPL
		      POP ACC
              RET
table_pleine:
			  MOV R7, #00h
			  POP DPH
			  POP DPL
		      POP ACC
			  RET
			  
;****************************************************************************** 


END



